package com.foodie.exception;

public class RestaurantException extends RuntimeException{

	public RestaurantException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RestaurantException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



	
	
	
}
