package com.foodie.exception;

public class ItemException extends RuntimeException {

	public ItemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
