package com.foodie.model;

public enum OrderStatus {

	PREPARING,
	OUTFORDELIVERY,
	DELIVERED,
	CANCELLED
}
